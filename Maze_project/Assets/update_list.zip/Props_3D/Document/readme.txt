/*--------------------------------------
Props 3D URP
© 2022 SigmoidButton
----------------------------------------
Those Shader Graph files requires "Shader Graph".
Would you please install "Shader Graph" from Package Manager.

Would you please set the appropriate texture on item of texture in surface inputs of those Shader Graph files.

About ShaderGraphLiquid
If the reverse side is not displayed when you use previous unity version, check the Two Sided checkbox in the Graph Settings menu.

Render Pipeline URP
Each of the models have the number of materials is 1
Each of the models have the number of textures is 0 to 5
(BaseMap,MaskMap,NormalMap,Alpha,Emission)
Texture size 1024 x 1024 pixels


Polygon
bag 916 triangles
bag_collider 240 triangles
bag_lowpoly 484 triangles
bag_lowpoly_collider 128 triangles

barrel 1596 triangles
barrel_collider 572 triangles
barrel_lowpoly 332 triangles
barrel_lowpoly_collider 76 triangles

bomb 450 triangles
bomb_collider 384 triangles
bomb_lowpoly 258 triangles
bomb_lowpoly_collider 192 triangles

bottle1 192 triangles
bottle1_liquid 100 triangles
bottle1_lowpoly 120 triangles
bottle1_liquid_lowpoly 60 triangles

bottle2 306 triangles
bottle2_liquid 214 triangles
bottle2_lowpoly 202 triangles
bottle2_liquid_lowpoly 142 triangles

bottle3 176 triangles
bottle3_liquid 84 triangles
bottle3_lowpoly 112 triangles
bottle3_liquid_lowpoly 52 triangles

candle 62 triangles
candle_collider 44 triangles
candle_lowpoly 38 triangles
candle_lowpoly_collider 20 triangles

coin 124 triangles
coin_lowpoly 28 triangles

crystal 374 triangles
crystal_lowpoly 98 triangles

diamond 174 triangles
diamond_collider 78 triangles
diamond_lowpoly 30 triangles

fire 168 triangles

hourglass 664 triangles
hourglass_collider 20 triangles
hourglass_lowpoly 298 triangles
hourglass_sand_lowpoly 174 triangles
hourglass_sand 334 triangles

lamp 1734 triangles
lamp_lowpoly 916 triangles

powder 300 triangles
powder_lowpoly 180 triangles

scroll 1078 triangles
scroll_collider 150 triangles
scroll_lowpoly 336 triangles

watch 1592 triangles
watch_collider 1352 triangles
watch_lowpoly 232 triangles

----------------------------------------*/